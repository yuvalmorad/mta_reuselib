/*!
 * ${copyright}
 */
sap.ui.define(["./../library","sap/ui/core/Control","./ExampleRenderer"],function(e,r,t){"use strict";var n=r.extend("ns.reuselib.controls.Example",{metadata:{library:"ns.reuselib",properties:{text:{type:"string",defaultValue:null}},events:{press:{}}},renderer:t});return n},true);