//@ui5-bundle ns/reuselib/library-preload.js
sap.ui.predefine("ns/reuselib/controls/Example",["./../library","sap/ui/core/Control","./ExampleRenderer"],function(e,r,t){"use strict";var s=r.extend("ns.reuselib.controls.Example",{metadata:{library:"ns.reuselib",properties:{text:{type:"string",defaultValue:null}},events:{press:{}}},renderer:t});return s},true);
sap.ui.predefine("ns/reuselib/controls/ExampleRenderer",[],function(){"use strict";var e={};e.render=function(e,r){e.write("<div");e.writeControlData(r);e.addClass("sapRULTExample");e.writeClasses();e.write(">");e.write(sap.ui.getCore().getLibraryResourceBundle("ns.reuselib").getText("ANY_TEXT"));e.writeEscaped(r.getText());e.write("</div>")};return e},true);
sap.ui.predefine("ns/reuselib/library",["sap/ui/core/library"],function(){"use strict";sap.ui.getCore().initLibrary({name:"ns.reuselib",version:"1.0.0",dependencies:["sap.ui.core"],noLibraryCSS:true,types:[],interfaces:[],controls:["ns.reuselib.controls.Example"],elements:[]});return ns.reuselib},false);
jQuery.sap.registerPreloadedModules({
"version":"2.0",
"modules":{
	"ns/reuselib/manifest.json":'{"_version":"1.12.0","sap.app":{"id":"ns.reuselib","type":"library","applicationVersion":{"version":"1.0.0"},"title":"lib","description":"","ach":"","offline":true},"sap.ui":{"technology":"UI5"},"sap.ui5":{"dependencies":{"minUI5Version":"1.52.0","libs":{"sap.ui.core":{"minUI5Version":"1.52.0"}}},"library":{"i18n":"messagebundle.properties","css":true,"content":{"controls":["ns.reuselib.Example"],"elements":[],"types":[],"interfaces":[]}}},"sap.cloud":{"service":"reuselibservice"}}'
}});
